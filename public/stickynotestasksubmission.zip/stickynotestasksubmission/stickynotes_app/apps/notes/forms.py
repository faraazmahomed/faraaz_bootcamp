from django import forms
from .models import Note


class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ["title", "content", "color", "is_pinned"]
        widgets = {
            "title": forms.TextInput(
                attrs={"placeholder": "Title...", "class": "form-input"}
            ),
            "content": forms.Textarea(
                attrs={
                    "placeholder": "Write your note here...",
                    "rows": 3,
                    "class": "form-input",
                }
            ),
            "color": forms.Select(attrs={"class": "form-input"}),
            "is_pinned": forms.CheckboxInput(attrs={"class": "form-checkbox"}),
        }
