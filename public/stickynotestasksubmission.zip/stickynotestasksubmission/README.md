# Sticky Notes Task Manager Application

A Django-based web application for creating, organizing, and managing sticky notes. This application allows users to quickly draft notes, assign visual color categories, pin important notes to the top of their dashboard, and delete completed notes.

---

## 📁 Repository & Submission Structure

```text
stickynotes_task_submission/
│
├── README.md                           <-- Project Documentation
├── design_diagrams/                    <-- Architecture & Design Artifacts
│   ├── use_case_diagram.png
│   ├── database_schema_erd.png
│   └── architecture_component_diagram.png
│
├── unit_tests/                         <-- Standalone Unit Test Backup
│   └── tests.py
│
└── stickynotes_app/                     <-- Core Django Source Directory
    ├── manage.py
    ├── stickynotes/                    <-- Project Configuration
    │   ├── settings.py
    │   ├── urls.py
    │   ├── asgi.py
    │   └── wsgi.py
    │
    └── apps/
        └── notes/                      <-- Sticky Notes Application
            ├── models.py
            ├── views.py
            ├── forms.py
            ├── urls.py
            ├── tests.py
            ├── admin.py
            └── templates/
                └── notes/
                    └── note_list.html